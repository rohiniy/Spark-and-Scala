import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.LinkedHashMap
import scala.collection.mutable.HashMap

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions

object FriendsRecommender {
    val FRIEND_FLAG = "F"

    def main(args: Array[String]): Unit = {
        val conf = new SparkConf().setAppName("FriendsRecommender");
        val sc = new SparkContext(conf);

        
        if (args.length != 2) {
          System.err.println("#############Error in providing arguments: <File containing user friends> <Output File>");
          System.exit(0);
        }
        
        val input = sc.textFile(args(0))
        // Create Rdd with  <user Id and friends Id list as string>
        val userFriendsRdd = input.map(line => line.split("\t")).filter(line => (line.length == 2))
        
        // Create Rdd for all ready friends
        val allReadyFrndsRdd = userFriendsRdd.map(line => createFrndsMap(line, 1.toInt))
        val allReadyFrndsflatmap = allReadyFrndsRdd.flatMap(line => line)        
        
        // Create Rdd for not all ready friends
        val notAllReadyFrndsRdd = userFriendsRdd.map(line => createFrndsMap(line, 0.toInt))
        val notAllReadyFrndsflatmap = notAllReadyFrndsRdd.flatMap(line => line)

        // Get union of the two Rdds
        val allFrndsAndNotFrndsRdd = allReadyFrndsflatmap.union(notAllReadyFrndsflatmap)
        
        // Get all same key members e.g.: (2-3,1), (2-3,4) and then make it as  (2-3,1#4)
        // Here get all the mutual friends for a pair of not friend users
        // For all ready friends (1-2, F), (2-4, F) - F denotes all ready friends
        val reduceByKeyRdd = allFrndsAndNotFrndsRdd.reduceByKey((mutualFrnd1, mutualFrnd2) => (mutualFrnd1 + '#' + mutualFrnd2))
        

        // Count the mutual friends
        // <friends pair> <count of mutual friends>
        val countMutualFriendsRdd = reduceByKeyRdd.map{line => 
          (line._1,
            // Get count of mutual friends of the user ids in key
            if (!(line._2).contains("F")) {(line._2).split("#").length} else {0})
        }
        
        // Get only the friends with mutual friends count > 0
        val filteredcountMutualFriendsRdd = countMutualFriendsRdd.map(line => (line._1, if ((line._2) > 0){line._2}else {" "}))
       
        // ReduceByKey to get all the recommendation for a user
        // Remove the Ids which have blank string in it, as they are all ready friends
        val recommendationsRDD = filteredcountMutualFriendsRdd.map(line => 
          (line._1.split("-")(0), (if (line._2.toString.equals(" ")){" "}else {(line._1.split("-")(1)).toString()}))
          ).reduceByKey((ele1,ele2) => (if(!ele1.equals(" ") && !ele2.equals(" ")) {(ele1 + "," + ele2)}
          else if(ele1.equals(" ") && !ele2.equals(" ")) {ele2} 
            else if(!ele1.equals(" ") && ele2.equals(" ")) {ele1} else {""} ))
        
            
        val finalOutput = recommendationsRDD.map(pair => (pair._1 + "\t" + pair._2))
        
        finalOutput.saveAsTextFile(args(1))
    }

    /**
     * Function to create maps for all ready friends
     * This accepts the Array[String] which represents <userId,FriendsIds>
     * This returns the map <userId>-<friend Id>F for each friend Id in the list of the user
     */
    def createFrndsMap(usersFriendsArr: Array[String], isAllreadyFrnd: Int): HashMap[String, String] = {
         
          // Create a hashmap for returning the map for all ready friends
         val outputHashmap = new HashMap[String, String]
        
        // Get the user Id
        val userId = usersFriendsArr(0)
        
        // Get the user's friends Id split
        val friendsIdArr = usersFriendsArr(1).split(",")
       
        // For each friend in the friends list of the user mention that <user Id> <friend Id> <all ready friends>
        if (isAllreadyFrnd == 1) {
          // put map : <user Id> <friend Id> <all ready friends>
          for (friend <- friendsIdArr) {
            outputHashmap.put(userId + "-" + friend, FRIEND_FLAG)
          }
        } else {
            // put map : <friend Id1>-<friend Id2> <userId whose friend list we are iterating>
            for (frnd1 <- friendsIdArr) {
              for (frnd2 <- friendsIdArr) {
                if (frnd1 != frnd2) {
                  outputHashmap.put(frnd1 + "-" + frnd2, userId)
                }
            }
          }
        }
        return outputHashmap
    }
}