package main.scala

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object MutualWithDetails {
    def main(args: Array[String]): Unit = {
        val conf = new SparkConf().setAppName("MutualFriendsWithDetails")
        val sc = new SparkContext(conf)

        if (args.length != 5) {
          System.err.println("#############Error in providing arguments: <user Id1> <user Id2> <File containing user friends> <File containing user details> <Output File>");
          System.exit(0);
        }
        val userA = args(0)
        val userB = args(1)
        val userFriendsFile = args(2)
        val userDetailsFile = args(3)

        // Create RDDs of the file contianing friends list and another for user details
        val userFriends = sc.textFile(userFriendsFile);
        val userDetails = sc.textFile(userDetailsFile);
       
        // Filter the user friends file with provided users
        val filteredInput1 = (userFriends.filter (line => (line.startsWith(userA + "\t"))))
        val filteredInput2 = (userFriends.filter (line => (line.startsWith(userB + "\t"))))
        
        // Take union of the filtered friends list of the provided users
        val filteredInput = filteredInput1.union(filteredInput2)
        
        // This provides the mutual friends with the countByValue > 1
        val finaloutput = filteredInput.map(line => (line.split("\t"))).flatMap(line => line(1).split(",")).countByValue().filter(line => (line._2 > 1)).map(line => line._1)
        
        val mutualFriendsID = sc.parallelize(finaloutput.toList)
        val mappedOutput = mutualFriendsID.map { user => (user,user) }
        
        // Get the user details for Name, Zipcode
        val mappedUser = userDetails.map { user => user.split(",")}.map {user => (user(0), (user(1) +" : "+ user(6)))}
        
        // Join the mutual friends RDD with the user details
        val filteredUserDetailsRdd = mappedOutput.join(mappedUser)
                
        val finalOutput = filteredUserDetailsRdd.map { user => ((userA + " " + userB + " " + "["), (((user._2)._2)+", "))
        }
        finalOutput.saveAsTextFile(args(4))
    }
}