package main.scala

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
/**
 * This class takes mutual friends of the provided users
 * Arguments: userId1 userId2 InputFile OutputFile
 */
object MutualFriends {
    def main(args: Array[String]): Unit = {
        val conf = new SparkConf().setAppName("MutualFriends")
        val sc = new SparkContext(conf)
        
        
        if (args.length != 4) {
          System.err.println("#############Error in providing arguments: <user Id1> <user Id2> <File containing user friends> <Output File>");
          System.exit(0);
        }
        val userA = args(0)
        val userB = args(1)
        val filepath = args(2)

        val input = sc.textFile(filepath);
       
        // Filter the file for the provided 2 users
        val filteredInput1 = (input.filter (line => (line.startsWith(userA + "\t"))))
        val filteredInput2 = (input.filter (line => (line.startsWith(userB + "\t"))))
        
        // Take the union of the friends list of the 2 users
        val filteredInput = filteredInput1.union(filteredInput2)
        // CountByValue which will count the friends and hence the one which will be more than 1 will be mutual friends
       //val finalOutput = filteredInput.map(line => (line.split("\t"))).flatMap(line => line(1).split(",")).countByValue().filter(line => (line._2 > 1)).map(line => line._1).foreach(println)
       
       val finalOutput = filteredInput.map(line => (line.split("\t"))).flatMap(line => line(1).split(",")).countByValue().filter(line => (line._2 > 1)).map(line => line._1)
       val finalOutputRdd = sc.parallelize(finalOutput.toSeq)
       finalOutputRdd.saveAsTextFile(args(3))
    }
}