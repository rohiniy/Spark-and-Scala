package main.scala

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object Mutual {
    def main(args: Array[String]): Unit = {
        
        val conf = new SparkConf().setAppName("FriendsAvgAge")
        val sc = new SparkContext(conf)

        if (args.length != 3) {
          System.err.println("#############Error in providing arguments: <File containing user friends> <File containing user details> <Output File>");
          System.exit(0);
        }
        
        val userFriendsFile = args(0)
        val userDetailsFile = args(1)
        
        // Create RDDs of the file containing friends list and another for user details
        val userFriends = sc.textFile(userFriendsFile);
        val userDetails = sc.textFile(userDetailsFile);
        
        //Create RDD containing <user Id> <his age> from the userDetails RDD
        val userIdAgeRdd = userDetails.map(line => line.split(",")).map {line => 
          (line(0),(java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) - (line(9).split("/")(2)).toInt))}
        
        // Create RDD containing <user Id> <list of friends>
        val userFriendsRdd = userFriends.map(line => (line.split("\t"))).map(line => (line(0),if(line.length == 2){line(1);}))
        
        // Create RDD containing <user Id> <address made up of fields of the input file>
        val userAddressRdd = userDetails.map(line => line.split(",")).map (line => 
          (line(0),line(3) +" " + line(4) +" " +line(5) + " " +line(6) + " " +line(7)))
        
        // Create RDD containing <user Id>, <his age>, <his friends ids list> by joining above 2 RDDs
        val joinedUserFrndsAndAge = userIdAgeRdd.join(userFriendsRdd)

        // Create maps <user's friend Id> <user's age> for all the friends in his list
        val frndAgeMap = joinedUserFrndsAndAge flatMap
        {case (key,(intVal, anyVal)) => (anyVal.toString().split(",").map(x => (x,intVal)))}
        
        // Calculate the no. of friends
        val noOfFrnds = frndAgeMap.countByKey().toArray
        // Calculate the total age of friends by using reduceByKey
        val frndTotalAge = frndAgeMap.reduceByKey(_+_)
        
        val noOfFrndsRdd = sc.parallelize(noOfFrnds) 
        
        // Join Total Age and No. of friends to take average
        val mapOfFrndsCountAndAge = frndTotalAge.join(noOfFrndsRdd)

        // Take average of the age of friends and sort in descending order and then take top 20
        val userFrndsAgeAvg = mapOfFrndsCountAndAge.map (x => (x._1, (x._2._1 / x._2._2))).sortBy(_._2,false).take(20)
        
        // Convert the userFrndsAgeAvg array to RDD for joining
        val userFrndsAgeAvgRdd = sc.parallelize(userFrndsAgeAvg)
        
        // Join user address RDD with AvgAge RDD
        val finalOutputRdd = userAddressRdd.join(userFrndsAgeAvgRdd)
       
        // Create map for final output :<user Id> <address> <average age of friends>
        val finalOutput = 
          finalOutputRdd.map { user => ((user._1)+", "+user._2._1+", "+user._2._2)}
        
        finalOutput.saveAsTextFile(args(2))
    }
}